<?php
require_once __DIR__ . '/config.php';

session_start();

function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header("Location: " . BASE_URL . "/auth/login.php");
        exit();
    }
}

function requireRole($roles) {
    requireLogin();
    if (!in_array($_SESSION['role'], (array)$roles)) {
        header("Location: " . BASE_URL . "/dashboard.php?error=akses_ditolak");
        exit();
    }
}

function loginUser($conn, $username, $password) {
    $username = mysqli_real_escape_string($conn, $username);
    $query = "SELECT * FROM users WHERE username = '$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $stored = $user['password_hash'];
        $valid = false;

        // Support bcrypt hash & legacy plain-text
        if (password_get_info($stored)['algo'] !== null && password_get_info($stored)['algoName'] !== 'unknown') {
            $valid = password_verify($password, $stored);
        } else {
            // Legacy plain-text comparison
            $valid = ($password === $stored);
            // Auto-upgrade to bcrypt
            if ($valid) {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $uid = (int)$user['user_id'];
                mysqli_query($conn, "UPDATE users SET password_hash = '$hashed' WHERE user_id = $uid");
            }
        }

        if ($valid) {
            session_regenerate_id(true);
            $_SESSION['user_id']     = $user['user_id'];
            $_SESSION['username']    = $user['username'];
            $_SESSION['role']        = $user['role'];
            $_SESSION['nama_lengkap'] = $user['nama_lengkap'];
            return true;
        }
    }
    return false;
}

function logoutUser() {
    session_unset();
    session_destroy();
    header("Location: " . BASE_URL . "/auth/login.php");
    exit();
}

function getRoleName($role) {
    $roles = [
        'admin'   => 'Administrator',
        'kasir'   => 'Kasir',
        'manager' => 'Manager'
    ];
    return isset($roles[$role]) ? $roles[$role] : $role;
}
?>
