<?php
require_once __DIR__ . '/includes/header.php';
requireRole(['admin', 'kasir', 'manager']);

// ==================== STAT CARDS ====================
$transaksiHariIni = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM transaksi_servis WHERE DATE(tanggal) = CURDATE()"))['jml'];
$omsetHariIni     = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi_servis WHERE DATE(tanggal) = CURDATE()"))['total'];
$antrian          = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM transaksi_servis WHERE DATE(tanggal) = CURDATE() AND status_servis = 'Menunggu'"))['jml'];
$pengerjaan       = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM transaksi_servis WHERE DATE(tanggal) = CURDATE() AND status_servis = 'Dikerjakan'"))['jml'];
$selesai          = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM transaksi_servis WHERE DATE(tanggal) = CURDATE() AND status_servis = 'Selesai Lunas'"))['jml'];
$stokKritis       = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM sparepart WHERE stok <= 5"))['jml'];

// ==================== FINANCE ====================
$omsetMinggu = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi_servis WHERE YEARWEEK(tanggal, 1) = YEARWEEK(CURDATE(), 1)"))['total'];
$omsetBulan  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi_servis WHERE MONTH(tanggal) = MONTH(CURDATE()) AND YEAR(tanggal) = YEAR(CURDATE())"))['total'];
$omsetTahun  = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(grand_total),0) as total FROM transaksi_servis WHERE YEAR(tanggal) = YEAR(CURDATE())"))['total'];

// Mekanik terajin bulan ini
$mekanikTerajin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT m.nama, COUNT(t.trans_id) as total_servis FROM transaksi_servis t JOIN mekanik m ON t.mekanik_id = m.mekanik_id WHERE MONTH(t.tanggal) = MONTH(CURDATE()) AND YEAR(t.tanggal) = YEAR(CURDATE()) GROUP BY m.mekanik_id, m.nama ORDER BY total_servis DESC LIMIT 1"));

// ==================== ANTRIAN HARI INI ====================
$queryAntrian = mysqli_query($conn, "SELECT v.no_polisi, t.status_servis FROM transaksi_servis t JOIN vehicle v ON t.vehicle_id = v.vehicle_id WHERE DATE(t.tanggal) = CURDATE() AND t.status_servis IN ('Menunggu', 'Dikerjakan') ORDER BY t.tanggal ASC LIMIT 8");

// ==================== SPAREPART TERLARIS ====================
$querySp = mysqli_query($conn, "SELECT s.nama_sparepart, SUM(td.qty) as total_qty FROM transaksi_servis_detail td JOIN sparepart s ON td.sparepart_id = s.sparepart_id JOIN transaksi_servis t ON td.trans_id = t.trans_id WHERE MONTH(t.tanggal) = MONTH(CURDATE()) AND YEAR(t.tanggal) = YEAR(CURDATE()) GROUP BY s.sparepart_id, s.nama_sparepart ORDER BY total_qty DESC LIMIT 5");
$dataTopSp = [];
while ($row = mysqli_fetch_assoc($querySp)) { $dataTopSp[] = $row; }

// ==================== KINERJA MEKANIK ====================
$queryKinerja = mysqli_query($conn, "SELECT m.nama, COUNT(t.trans_id) as total_servis FROM transaksi_servis t JOIN mekanik m ON t.mekanik_id = m.mekanik_id WHERE MONTH(t.tanggal) = MONTH(CURDATE()) AND YEAR(t.tanggal) = YEAR(CURDATE()) GROUP BY m.mekanik_id, m.nama ORDER BY total_servis DESC LIMIT 6");
$dataKinerja = [];
$maxServis = 1;
while ($row = mysqli_fetch_assoc($queryKinerja)) { $dataKinerja[] = $row; $maxServis = max($maxServis, $row['total_servis']); }

// ==================== OMZET BULANAN (Chart) ====================
$queryOmzetBulanan = mysqli_query($conn, "SELECT MONTH(tanggal) as bulan, SUM(grand_total) as total FROM transaksi_servis WHERE YEAR(tanggal) = YEAR(CURDATE()) GROUP BY MONTH(tanggal) ORDER BY bulan ASC");
$dataOmzetBulanan = [];
while ($row = mysqli_fetch_assoc($queryOmzetBulanan)) { $dataOmzetBulanan[] = $row; }

// ==================== TIPE KENDARAAN (Chart) ====================
$queryTipe = mysqli_query($conn, "SELECT COALESCE(v.tipe_kendaraan, 'Lainnya') as tipe, COUNT(t.trans_id) as total FROM transaksi_servis t JOIN vehicle v ON t.vehicle_id = v.vehicle_id GROUP BY v.tipe_kendaraan");
$dataTipe = [];
while ($row = mysqli_fetch_assoc($queryTipe)) { $dataTipe[] = $row; }
?>

<div class="page-header">
    <div class="page-title">
        <h4><i class="bi bi-speedometer2 me-2"></i>Dashboard</h4>
        <p class="page-subtitle"><?php echo date('l, d F Y'); ?> &mdash; ringkasan aktivitas bengkel hari ini</p>
    </div>
    <span class="badge bg-primary">v2026.1</span>
</div>

<!-- ==================== KPI CARDS ==================== -->
<div class="row mb-4 g-3">
    <div class="col-xl-3 col-md-6">
        <div class="kpi-card">
            <div class="kpi-icon ic-navy"><i class="bi bi-speedometer2"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Transaksi Hari Ini</div>
                <h3 class="kpi-value"><?php echo $transaksiHariIni; ?></h3>
                <div class="kpi-sub"><span class="kpi-chip chip-ok"><i class="bi bi-check-circle"></i> <?php echo $selesai; ?> selesai</span></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="kpi-card">
            <div class="kpi-icon ic-orange"><i class="bi bi-cash-stack"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Omset Hari Ini</div>
                <h3 class="kpi-value"><?php echo formatRupiah($omsetHariIni); ?></h3>
                <div class="kpi-sub">Bulan ini: <strong class="text-dark"><?php echo formatRupiah($omsetBulan); ?></strong></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="kpi-card">
            <div class="kpi-icon ic-teal"><i class="bi bi-list-ul"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Antrian</div>
                <h3 class="kpi-value"><?php echo $antrian; ?></h3>
                <div class="kpi-sub">menunggu antrean servis</div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="kpi-card">
            <div class="kpi-icon ic-violet"><i class="bi bi-wrench-adjustable"></i></div>
            <div class="kpi-body">
                <div class="kpi-label">Pengerjaan</div>
                <h3 class="kpi-value"><?php echo $pengerjaan; ?></h3>
                <div class="kpi-sub">
                    <?php if ($stokKritis > 0): ?>
                    <span class="kpi-chip chip-warn"><i class="bi bi-exclamation-triangle"></i> <?php echo $stokKritis; ?> stok kritis</span>
                    <?php else: ?>
                    <span class="kpi-chip chip-ok"><i class="bi bi-check-circle"></i> stok aman</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- ==================== BENTO: CHART + KEUANGAN + ANTRIAN ==================== -->
<div class="row mb-4 g-4">
    <div class="col-xl-8">
        <div class="card h-100">
            <div class="card-header bento-head">
                <div class="bento-title">
                    <span class="bento-badge bb-orange"><i class="bi bi-bar-chart-fill"></i></span>
                    Omzet Bulanan <?php echo date('Y'); ?>
                </div>
                <div class="d-flex gap-2">
                    <span class="bento-chip"><i class="bi bi-tools text-primary"></i> <?php echo $transaksiHariIni; ?> transaksi</span>
                    <span class="bento-chip"><i class="bi bi-calendar3 text-success"></i> <?php echo formatRupiah($omsetTahun); ?></span>
                </div>
            </div>
            <div class="card-body"><canvas id="chartOmzet" height="150"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card mb-4">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-wallet2 me-1 text-warning"></i> Keuangan</h6></div>
            <div class="card-body">
                <div class="minitile-grid">
                    <div class="minitile">
                        <div class="mt-label">Minggu Ini</div>
                        <div class="mt-value mt-orange"><?php echo formatRupiah($omsetMinggu); ?></div>
                    </div>
                    <div class="minitile">
                        <div class="mt-label">Bulan Ini</div>
                        <div class="mt-value mt-green"><?php echo formatRupiah($omsetBulan); ?></div>
                    </div>
                    <div class="minitile">
                        <div class="mt-label">Tahun Ini</div>
                        <div class="mt-value mt-navy"><?php echo formatRupiah($omsetTahun); ?></div>
                    </div>
                    <div class="minitile">
                        <div class="mt-label">Mekanik Terajin</div>
                        <div class="mt-value"><?php echo $mekanikTerajin ? htmlspecialchars($mekanikTerajin['nama']) : '&mdash;'; ?></div>
                        <div class="mt-label mt-1"><?php echo $mekanikTerajin ? $mekanikTerajin['total_servis'] . ' servis bulan ini' : 'Belum ada data'; ?></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-clock-history me-1 text-info"></i> Antrian Hari Ini</h6></div>
            <div class="card-body p-0">
                <?php $hasAntrian = false; while ($a = mysqli_fetch_assoc($queryAntrian)): $hasAntrian = true; ?>
                <div class="queue-item">
                    <span class="queue-nopol"><?php echo htmlspecialchars($a['no_polisi']); ?></span>
                    <?php echo setStatusBadge($a['status_servis']); ?>
                </div>
                <?php endwhile; ?>
                <?php if (!$hasAntrian): ?>
                <div class="empty-state py-4">
                    <i class="bi bi-calendar-x"></i>
                    <div class="es-title">Tidak ada antrian</div>
                    <div class="es-sub">Belum ada servis yang menunggu hari ini</div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- ==================== BENTO: CHART + KINERJA + SPAREPART ==================== -->
<div class="row g-4">
    <div class="col-xl-4 col-md-6">
        <div class="card h-100">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-diagram-3 me-1 text-violet"></i> Tipe Kendaraan Servis</h6></div>
            <div class="card-body"><canvas id="chartTipe" height="150"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4 col-md-6">
        <div class="card h-100">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-person-workspace me-1 text-primary"></i> Kinerja Mekanik</h6></div>
            <div class="card-body">
                <?php if (count($dataKinerja) > 0): ?>
                    <?php $colors = ['#3b82f6','#10b981','#f59e0b','#8b5cf6','#f97316','#ef4444']; ?>
                    <?php foreach ($dataKinerja as $i => $mk): ?>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between small mb-1">
                            <span class="fw-semibold"><?php echo htmlspecialchars($mk['nama']); ?></span>
                            <span class="fw-bold text-muted"><?php echo $mk['total_servis']; ?> servis</span>
                        </div>
                        <div class="progress-soft">
                            <div class="progress-bar" style="width:<?php echo ($mk['total_servis'] / $maxServis * 100); ?>%;background:<?php echo $colors[$i % 6]; ?>;"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="bi bi-clipboard-data"></i>
                        <div class="es-title">Belum ada data</div>
                        <div class="es-sub">Kinerja mekanik tampil di sini</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card h-100">
            <div class="card-header"><h6 class="mb-0"><i class="bi bi-fire me-1 text-danger"></i> Sparepart Terlaris</h6></div>
            <div class="card-body p-0">
                <?php if (count($dataTopSp) > 0): ?>
                    <?php foreach ($dataTopSp as $sp): ?>
                    <div class="rank-item">
                        <span class="rank-no"><?php echo $sp['total_qty']; ?></span>
                        <span class="rank-name"><?php echo htmlspecialchars($sp['nama_sparepart']); ?></span>
                        <span class="badge bg-primary"><?php echo $sp['total_qty']; ?> pcs</span>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state">
                        <i class="bi bi-box"></i>
                        <div class="es-title">Belum ada data</div>
                        <div class="es-sub">Sparepart terlaris tampil di sini</div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
// Omzet Bulanan Bar Chart
var bulanNama = ['','Jan','Feb','Mar','Apr','Mei','Jun','Jul','Ags','Sep','Okt','Nov','Des'];
var omzetData = <?php echo json_encode($dataOmzetBulanan); ?>;
new Chart(document.getElementById('chartOmzet'), {
    type: 'bar',
    data: {
        labels: omzetData.map(d => bulanNama[d.bulan]),
        datasets: [{
            label: 'Omzet',
            data: omzetData.map(d => d.total),
            backgroundColor: '#0a1628',
            hoverBackgroundColor: '#f97316',
            borderRadius: 6
        }]
    },
    options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, grid: { color: '#f1f5f9' } }, x: { grid: { display: false } } } }
});

// Tipe Kendaraan Pie Chart
var tipeData = <?php echo json_encode($dataTipe); ?>;
new Chart(document.getElementById('chartTipe'), {
    type: 'doughnut',
    data: {
        labels: tipeData.map(d => d.tipe || 'Lainnya'),
        datasets: [{
            data: tipeData.map(d => d.total),
            backgroundColor: ['#0a1628','#1e3a5f','#f97316','#fb923c','#0891b2','#6d28d9']
        }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 }, usePointStyle: true } } } }
});

// Top 5 Sparepart Horizontal Bar
var spData = <?php echo json_encode($dataTopSp); ?>;
new Chart(document.getElementById('chartSparepart'), {
    type: 'bar',
    data: {
        labels: spData.map(d => d.nama_sparepart.length > 12 ? d.nama_sparepart.substring(0,12)+'...' : d.nama_sparepart),
        datasets: [{
            label: 'Qty',
            data: spData.map(d => d.total_qty),
            backgroundColor: ['#0a1628','#1e3a5f','#f97316','#fb923c','#0891b2'],
            borderRadius: 4
        }]
    },
    options: { indexAxis: 'y', responsive: true, plugins: { legend: { display: false } }, scales: { x: { beginAtZero: true, grid: { color: '#f1f5f9' } }, y: { grid: { display: false } } } }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
